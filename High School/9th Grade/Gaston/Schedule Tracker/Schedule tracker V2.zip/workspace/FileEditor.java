import java.util.*;
import java.io.*;
import java.text.*;

public class FileEditor {

    public static void main(String[] args) {

    }

    public static void saveObject(Object obj) {

    }

    public static void readObject(Object obj) {

    }

    /**
     * Opens and reads a file then returns the contents of the file
     * @param fileName the name of the file to be opened/read
     * @return String array with the text contents of the file
     */

    public static ArrayList < String > readFile(String fileName) {

        // This will reference one line at a time
        String line = null;
        ArrayList < String > text = new ArrayList < > ();

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader =
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader =
                new BufferedReader(fileReader);

            while ((line = bufferedReader.readLine()) != null) {
                text.add(line);
            }

            bufferedReader.close();
        } catch (FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" +
                fileName + "'");
        } catch (IOException ex) {
            System.out.println(
                "Error reading file '" +
                fileName + "'");
        }
        return text;
    }

        /**
     * Creates a file with the specified name, and text on a new line
     * @param name The name to be given to the file
     * @param test A string array that will be put into the file, each element is on a new line
     * @return void, created a new file
     */

    public static void writeFile(String name, String[] text) {
        // The name of the file to open.
        String fileName = name;

        try {
            // Assume default encoding.
            FileWriter fileWriter = new FileWriter(fileName);

            // Always wrap FileWriter in BufferedWriter.
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            // Note that write() does not automatically
            // append a newline character.
            for (String line: text) {
                bufferedWriter.write(line);
                bufferedWriter.newLine();
            }

            // Always close files.
            bufferedWriter.close();
        } catch (IOException ex) {
            System.out.println("Error writing to file '" + fileName + "'");

        }
    }
}