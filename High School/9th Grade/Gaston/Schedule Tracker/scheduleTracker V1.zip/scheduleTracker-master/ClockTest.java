import java.util.Scanner;

public class ClockTest {
    private static Scanner scan = new Scanner(System.in);
    private static FileEditor fileEditor = new FileEditor();
    private static String command;
    private static String[] classList = new String[9];
    private static Clock myClock = new Clock();

    public static void main(String[] args) {
        System.out.println("");
        getHelp();
        test();
        while(true) {
            System.out.println("");
            System.out.print("Input Command: ");
            command = scan.nextLine().toUpperCase();
            System.out.println("");
            if (command.equals("HELP")) {
                getHelp();
            } else if(command.equals("SETDAY")) {
                setDay();
                myClock.getDay();
            } else if (command.equals("GETDAY")) {
                System.out.println(myClock.getDay());
            } else if (command.equals("SETCLASS")) {
                setClass();
            } else if (command.equals("GETCLASS")) {
                myClock.printCurrentClass();
            } else if (command.equals("GETLIST")) {
                myClock.getClassList();
            } else if (command.equals("SETLUNCH")) {
                setLunch();
            } else if (command.equals("SETWEDNESDAYLUNCH")) {
                setWednesdayLunch();
            } else if (command.equals("GETLUNCH")) {
                System.out.println("Lunch: " + myClock.getLunch());
            } else if (command.equals("END")) {
                break;
            } else {
                System.out.println("Could not understand command");
            }
        }
    }

    private static void test() {
        myClock.printCurrentClass();
        myClock.setDay("EVEN");
        System.out.println(myClock.getDay());
        myClock.getClassList();
        myClock.setDay("ODD");
        System.out.println(myClock.getDay());
        myClock.getClassList();
        myClock.setLunch('A');
        System.out.println("A lunch -");
        myClock.getClassList();
        myClock.setLunch('B');
        System.out.println("B lunch -");
        myClock.getClassList();
        myClock.setLunch('C');
        System.out.println("C lunch -");
        myClock.getClassList();
    }

    private static void getHelp() {
        System.out.println("Help");
        System.out.println("    Setday");
        System.out.println("        Set day to even or odd");
        System.out.println("    Getday");
        System.out.println("        Get if the day is even or odd");
        System.out.println("    Setclass");
        System.out.println("        Sets the list of classes");
        System.out.println("    Getclass");
        System.out.println("        Print current class and time remaining");
        System.out.println("    Getlist");
        System.out.println("        Prints a list of all classes");
        System.out.println("    End");
        System.out.println("        End the program");
    }

    private static void setClass() {
                for(int i = 0; i < 9; i++) {
                    System.out.print("Next Class: ");
                    classList[i] = scan.nextLine();
                }
                fileEditor.writeFile("classList2.txt", classList);
    }

    private static void setDay() {
                System.out.print("Even or Odd? ");
                command = scan.nextLine().toUpperCase();
                myClock.setDay(command);
    }

    private static void setLunch() {
        System.out.print("A, B, or C? ");
        Character lunchLetter = Character.toUpperCase(scan.next().charAt(0));
        myClock.setLunch(lunchLetter);
    }

    private static void getLunch() {
        System.out.println(myClock.getLunch() + " lunch");
    }

    private static void setWednesdayLunch() {
        System.out.print("A, B, or C? ");
        Character lunchLetter = Character.toUpperCase(scan.next().charAt(0));
        myClock.setWednesdayLunch(lunchLetter);
    }

    private static void getWednesdayLunch() {
        System.out.println(myClock.getWednesdayLunch() + " lunch");
    }

}