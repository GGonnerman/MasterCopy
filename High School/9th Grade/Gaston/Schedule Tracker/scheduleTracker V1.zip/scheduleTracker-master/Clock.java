import java.io.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;
import java.text.*;
import java.lang.*;


public class Clock {

    private String evenOrOdd;
    private Character lunch;
    private Character wednesdayLunch;

    private int[] currentTime;
    private String[] info = new String[3];

    private ArrayList < String > printClassList = new ArrayList < String > ();

    private LinkedHashMap < String, int[] > schedule = new LinkedHashMap < String, int[] > ();

    private Time myTime = new Time();
    private FileEditor fileEditor = new FileEditor();;

    public static void main(String[] args) {



    }

    Clock() {
        for(int i = 0; i < 3; i++) {
            info[i] = fileEditor.readFile("info.txt").get(i);
        }
        evenOrOdd = info[0];
        setLunch(info[1].charAt(0));
        setWednesdayLunch(info[2].charAt(0));

        update();
    }

    public void update() {
        schedule.clear();
        printClassList.clear();

        currentTime = myTime.getTime();


        ArrayList < String > classList;
        ArrayList < String > classTimes;

        if (myTime.isWednesday()) {
            classList = fileEditor.readFile("wednesdayClassList2.txt");
            classTimes = fileEditor.readFile("wednesdaySchedule.txt");
        } else {
            classList = fileEditor.readFile("classList2.txt");
            classTimes = fileEditor.readFile("schedule.txt");
        }

        for (int period = 0; period < classList.size(); period++) {
            String className = classList.get(period);
            if (className.contains(" ")) {
                className = className.split(" ")[(evenOrOdd.equals("EVEN")) ? 0 : 1];
            }

            String[] times = classTimes.get(period).split("[: ]");
            int[] startEndTimes = new int[times.length/2];
            for(int i = 0; i < times.length / 2; i++) {
                startEndTimes[i] = changeToMinutes(Integer.parseInt(times[i + i]), Integer.parseInt(times[i + i + 1]));
            }

            String visualClassTimes;

            if(startEndTimes.length > 2) {
                visualClassTimes = String.format("Class: %s Start: %s:%s End: %s:%s Resume: %s:%s End: %s:%s", className, times[0], times[1], times[2], times[3], times[4], times[5], times[6], times[7]);
            } else {
                visualClassTimes = String.format("Class: %s Start: %s:%s End: %s:%s", className, times[0], times[1], times[2], times[3]);
            }

            printClassList.add(visualClassTimes);
            schedule.put(className, startEndTimes);
        }
    }

    public void getClassList() {
        update();
        for (String classLines: printClassList) {
            System.out.println(classLines);
        }
    }

    /**
     * Takes in a time and converts in to the amount of minutes
     * @param hours
     * @param minutes
     * @return the amount of minutes that has passed
     */

    public void printCurrentClass() {
        update();
        int timeInMinutes = changeToMinutes(currentTime[0], currentTime[1]);
        boolean foundClass = false;
        String currentClassName = "";
        int timeUntilOver = 0;

        //Look through the map to see if current time is within a class' times
        for (Map.Entry < String, int[] > classSet: schedule.entrySet()) {
            String className = classSet.getKey();
            int[] classTime = classSet.getValue();

            if (classTime[0] < timeInMinutes && timeInMinutes < classTime[1]) {

                currentClassName = className + " is over";
                if(classTime.length > 2) {
                    timeUntilOver = classTime[3] - timeInMinutes;
                } else {
                    timeUntilOver = classTime[1] - timeInMinutes;
                }
                foundClass = true;

            }
            if (classTime.length > 2) {
                if (classTime[2] < timeInMinutes && timeInMinutes < classTime[3]) {
                    currentClassName = className + " is over";
                    timeUntilOver = classTime[3] - timeInMinutes;
                    foundClass = true;

                }
            }

        }
        // If not in a class, find how long until the next class starts
        if (!foundClass) {

            int startTime = schedule.entrySet().iterator().next().getValue()[0];
            int endTime = lastValueInHashMap(schedule);

            if (timeInMinutes < startTime) {

                currentClassName = "school starts";
                timeUntilOver = startTime - timeInMinutes;

            } else if (timeInMinutes > endTime) {

                currentClassName = "school starts";
                timeUntilOver = (1440 - timeInMinutes) + startTime;

            } else {

                currentClassName = "Passing Time is over";
                for (Map.Entry < String, int[] > classSet: schedule.entrySet()) {
                    for (Map.Entry < String, int[] > classSetTwo: schedule.entrySet()) {
                        if (timeInMinutes > classSet.getValue()[1] && timeInMinutes < classSetTwo.getValue()[0]) {
                            timeUntilOver = classSetTwo.getValue()[0] - timeInMinutes;
                            break;
                        }
                    }
                }
            }
        }

        // Print out what class you are in and how long until it is over
        System.out.println(timeUntilOver + " minutes until " + currentClassName.replaceAll("_", " "));
    }

    public void setDay(String evenOrOdd) {
        update();

        if (evenOrOdd.equals("EVEN") || evenOrOdd.equals("ODD")) {

            this.evenOrOdd = evenOrOdd;

            info[0] = evenOrOdd;
            fileEditor.writeFile("info.txt", info);
        }
    }

    public String getDay() {
        update();
        return evenOrOdd.charAt(0) + evenOrOdd.substring(1).toLowerCase();
    }

    private static int changeToMinutes(int hours, int minutes) {
        return (hours * 60) + minutes;
    }

    private static int lastValueInHashMap(LinkedHashMap < String, int[] > myHashMap) {
        Iterator < Map.Entry < String, int[] >> iterator = myHashMap.entrySet().iterator();
        int lastValue = 0;
        while (iterator.hasNext()) {
            lastValue = iterator.next().getValue()[1];
        }
        return lastValue;
    }

    public Character getLunch() {
        return lunch;
    }

    public void setLunch(Character lunch) {

        String[] scheduleFile = fileEditor.readFile("schedule.txt").toArray(new String[0]);

        switch(lunch) {
            case 'A' :
                scheduleFile[4] = "12:00 12:50";
                scheduleFile[5] = "11:35 12:00";
                lunch = 'A';
                break;

            case 'B' :
                scheduleFile[4] = "11:35 12:00 12:26 12:50";
                scheduleFile[5] = "12:00 12:26";
                lunch = 'B';
                break;

            case 'C' :
                scheduleFile[4] = "11:35 12:26";
                scheduleFile[5] = "12:26 12:50";
                lunch = 'C';
                break;
        }

        info[1] = String.valueOf(lunch);
        fileEditor.writeFile("info.txt", info);
        fileEditor.writeFile("schedule.txt", scheduleFile);
    }

    public void setWednesdayLunch(Character lunch) {

        String[] scheduleFile = fileEditor.readFile("wednesdaySchedule.txt").toArray(new String[0]);

        switch(lunch) {
            case 'A' :
                scheduleFile[5] = "11:50 12:45";
                scheduleFile[6] = "11:35 11:50";
                wednesdayLunch = 'A';
                break;

            case 'B' :
                scheduleFile[5] = "11:35 11:50 12:20 12:45";
                scheduleFile[6] = "11:50 12:20";
                wednesdayLunch = 'B';
                break;

            case 'C' :
                scheduleFile[5] = "11:35 12:20";
                scheduleFile[6] = "12:20 12:45";
                wednesdayLunch = 'C';
                break;
        }

        info[2] = String.valueOf(lunch);
        fileEditor.writeFile("info.txt", info);
        fileEditor.writeFile("wednesdaySchedule.txt", scheduleFile);
    }

    public Character getWednesdayLunch() {
        return wednesdayLunch;
    }

}