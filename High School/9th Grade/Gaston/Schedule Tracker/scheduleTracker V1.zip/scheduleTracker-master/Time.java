import java.util.*;
import java.text.*;
import java.io.*;

public class Time {

    public static int[] getTime() {
        int[] time = new int[2];

        Date date = new Date();
        DateFormat hrFormat = new SimpleDateFormat("HH");
        DateFormat mmFormat = new SimpleDateFormat("mm");

        TimeZone cstTime = TimeZone.getTimeZone("CST");

        hrFormat.setTimeZone(cstTime);
        mmFormat.setTimeZone(cstTime);

        time[0] = Integer.parseInt(hrFormat.format(date));
        time[1] = Integer.parseInt(mmFormat.format(date));

        return time;
    }

    public static boolean isWednesday() {
        Date now = new Date();
        DateFormat dayName = new SimpleDateFormat("EEEE");
        //System.out.println(dayName.format(now));
        return dayName.format(now).equals("Wednesday");
    }
}